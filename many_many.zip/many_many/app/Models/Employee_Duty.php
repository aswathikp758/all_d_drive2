<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee_Duty extends Model
{
    use HasFactory;
      protected $table='employee_duties'; 
    protected $timestamp=false;
}
