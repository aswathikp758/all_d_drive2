<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\Duty;
class EmployeeController extends Controller
{
    // public function show_duties($id){
    //     $duty=Employee::find($id)->employees;
    //     return $duty;
    // }
}
