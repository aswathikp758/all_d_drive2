<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Duty;
use App\Models\Employee;
class DutyController extends Controller
{
    public function listUsers($id)
  {
 //return Employee::all();
return Employee::find($id)->duty;
//$con=Employee::find($id)->duty;
 //return $con;


  //return Duty::all();
  // return Duty::find(2)->employee;
  }
}
